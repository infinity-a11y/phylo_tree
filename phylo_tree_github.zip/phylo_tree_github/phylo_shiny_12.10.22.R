# Phylogenetic Visualization Of cgMLST data in a Shiny App
# Author: Marian Freisleben
# Date: 07.10.2022

if (!require(shiny)) install.packages('shiny')
library(shiny)
if (!require(shinyWidgets)) install.packages('shinyWidgets')
library(shinyWidgets)
if (!require(shinydashboard)) install.packages('shinydashboard')
library(shinydashboard)
if (!require(dashboardthemes)) install.packages('dashboardthemes')
library(dashboardthemes)
if (!require(ggplot2)) install.packages('ggplot2')
library(ggplot2)
if (!require(ggplotify)) install.packages('ggplotify')
library(ggplotify)
if (!require(ape)) install.packages('ape')
library(ape)
if (!require(treeio)) install.packages('treeio')
library(treeio)
if (!require(ggtree)) install.packages('ggtree')
library(ggtree)
if (!require(ggtreeExtra)) install.packages('ggtreeExtra')
library(ggtreeExtra)
if (!require(tidyverse)) install.packages('tidyverse')
library(tidyverse)
if (!require(ggtree)) install.packages('ggtree')
library(ggtree)
if (!require(tidytree)) install.packages('tidytree')
library(tidytree)

################ User Interface ################

ui <- dashboardPage(
  
    # Title 
    dashboardHeader(title = span(img(src="PhyloTree.jpg", width = 190))),

    dashboardSidebar(
      tags$style("label{color: white;}"),
      br(), br(),
      sidebarMenu(
        id = "tabs",
        menuItem(
          text = "Upload Data",
          tabName = "upload",
                 icon = icon("upload")
          ),
        menuItem(
          text = "Visualization",
          tabName = "visualization",
          icon = icon("code-branch")
          ),
        menuItem(
           text = "Download Report",
           tabName = "report",
           icon = icon("download")
           ),
        br(), br(), br(), br(), br(), br(),
        conditionalPanel(
          "input.tabs=='visualization'",
          column(
            width = 12,
            h4(p("Choose data source"), style = "color:white"),
            br(),
            radioButtons(
              "generate_tree",
              label = NULL,
              choices = c("Uploaded data", "Random")
              ),
            conditionalPanel(
              "input.generate_tree=='Uploaded data'",
              br(), br()
              ),
            conditionalPanel(
              "input.generate_tree=='Random'",
              br(),
              numericInput(
                "ntree",
                label = h5("# branches", style = "color:white"), 
                value = 30,
                max = 500,
                width = "110px")
              )
            ),
          br(), br(),
          column(
            width = 12,
            align = "center",
            conditionalPanel(
               "input.generate_tree=='Uploaded data'",
               br(), br(), br(),
               actionButton(inputId = "make_tree", label = "Generate Tree")
              ),
            conditionalPanel(
               "input.generate_tree=='Random'",
               br(), br(), br(),
               actionButton(inputId = "random_tree", label = "Generate Tree")
              )
            )
          )
        )
      ),

    dashboardBody(
      shinyDashboardThemeDIY(
      ### general
      appFontFamily = "Tahoma"
      ,appFontColor = "#000000"
      ,primaryFontColor = "rgb(0,0,0)"
      ,infoFontColor = "rgb(0,0,0)"
      ,successFontColor = "rgb(0,0,0)"
      ,warningFontColor = "rgb(0,0,0)"
      ,dangerFontColor = "rgb(0,0,0)"
      ,bodyBackColor = cssGradientThreeColors(
        direction = "down"
        ,colorStart = "#282f38"
        ,colorMiddle = "#384454"
        ,colorEnd = "#495d78"
        ,colorStartPos = 0
        ,colorMiddlePos = 50
        ,colorEndPos = 100
      )
      
      ### header
      ,logoBackColor = "#282f38"
      
      ,headerButtonBackColor = "#282f38"
      ,headerButtonIconColor = "#18ece1"
      ,headerButtonBackColorHover = "#282f38"
      ,headerButtonIconColorHover = "#ffffff"
      
      ,headerBackColor = "#282f38"
      ,headerBoxShadowColor = "#aaaaaa"
      ,headerBoxShadowSize = "0px 0px 0px"
      
      ### sidebar
      ,sidebarBackColor = cssGradientThreeColors(
        direction = "down"
        ,colorStart = "#282f38"
        ,colorMiddle = "#384454"
        ,colorEnd = "#495d78"
        ,colorStartPos = 0
        ,colorMiddlePos = 50
        ,colorEndPos = 100
      )
      ,sidebarPadding = 0
      
      ,sidebarMenuBackColor = "transparent"
      ,sidebarMenuPadding = 0
      ,sidebarMenuBorderRadius = 0
      
      ,sidebarShadowRadius = "5px 5px 5px"
      ,sidebarShadowColor = "#282f38"
      
      ,sidebarUserTextColor = "#ffffff"
      
      ,sidebarSearchBackColor = "rgb(55,72,80)"
      ,sidebarSearchIconColor = "rgb(153,153,153)"
      ,sidebarSearchBorderColor = "rgb(55,72,80)"
      
      ,sidebarTabTextColor = "rgb(255,255,255)"
      ,sidebarTabTextSize = 15
      ,sidebarTabBorderStyle = "none none solid none"
      ,sidebarTabBorderColor = "rgb(35,106,135)"
      ,sidebarTabBorderWidth = 0
      
      ,sidebarTabBackColorSelected = cssGradientThreeColors(
        direction = "right"
        ,colorStart = "rgba(44,222,235,1)"
        ,colorMiddle = "rgba(44,222,235,1)"
        ,colorEnd = "rgba(0,255,213,1)"
        ,colorStartPos = 0
        ,colorMiddlePos = 30
        ,colorEndPos = 100
      )
      ,sidebarTabTextColorSelected = "rgb(0,0,0)"
      ,sidebarTabRadiusSelected = "0px 20px 20px 0px"
      
      ,sidebarTabBackColorHover = cssGradientThreeColors(
        direction = "right"
        ,colorStart = "rgba(44,222,235,1)"
        ,colorMiddle = "rgba(44,222,235,1)"
        ,colorEnd = "rgba(0,255,213,1)"
        ,colorStartPos = 0
        ,colorMiddlePos = 30
        ,colorEndPos = 100
      )
      ,sidebarTabTextColorHover = "rgb(50,50,50)"
      ,sidebarTabBorderStyleHover = "none none solid none"
      ,sidebarTabBorderColorHover = "rgb(75,126,151)"
      ,sidebarTabBorderWidthHover = 1
      ,sidebarTabRadiusHover = "0px 20px 20px 0px"
      
      ### boxes
      ,boxBackColor = "#ffffff"
      ,boxBorderRadius = 7
      ,boxShadowSize = "0px 1px 1px"
      ,boxShadowColor = "#ffffff"
      ,boxTitleSize = 16
      ,boxDefaultColor = "#3d9970"
      ,boxPrimaryColor = "#7d9aa0"
      ,boxInfoColor = "#3d9970"
      ,boxSuccessColor = "#3d9970"
      ,boxWarningColor = "#ffffff"
      ,boxDangerColor = "#ffffff"
      
      ,tabBoxTabColor = "#ffffff"
      ,tabBoxTabTextSize = 14
      ,tabBoxTabTextColor = "rgb(0,0,0)"
      ,tabBoxTabTextColorSelected = "rgb(0,0,0)"
      ,tabBoxBackColor = "#ffffff"
      ,tabBoxHighlightColor = "#ffffff"
      ,tabBoxBorderRadius = 5
      
      ### inputs
      ,buttonBackColor = "#282f38"
      ,buttonTextColor = "#ffffff"
      ,buttonBorderColor = "#282f38"
      ,buttonBorderRadius = 10
      
      ,buttonBackColorHover = cssGradientThreeColors(
        direction = "right"
        ,colorStart = "rgba(44,222,235,1)"
        ,colorMiddle = "rgba(44,222,235,1)"
        ,colorEnd = "rgba(0,255,213,1)"
        ,colorStartPos = 0
        ,colorMiddlePos = 30
        ,colorEndPos = 100
      )
      ,buttonTextColorHover = "#000000"
      ,buttonBorderColorHover = "transparent"
      
      ,textboxBackColor = "#ffffff"
      ,textboxBorderColor = "transparent"
      ,textboxBorderRadius = 10
      ,textboxBackColorSelect = "#ffffff"
      ,textboxBorderColorSelect = "#000000"
      
      ### tables
      ,tableBackColor = "rgb(255,255,255)"
      ,tableBorderColor = "rgb(240,240,240)"
      ,tableBorderTopSize = 1
      ,tableBorderRowSize = 1
    ),
    tabItems(
    
    tabItem(
       tabName = "upload",
       br(), br(), br(),
       column(
          width = 12,
          align = "center",
          h3(p("Upload Tree"), style = "color:white"),
          br(), br(), br(),
          fileInput(
             inputId = "file",
             label = NULL,
             multiple = TRUE,
             placeholder = "Select file"
             ),
          br(),
          selectInput(
             "select", 
             label = h5("Select format", style = "color:white"),
             choices = list("BEAST", "MEGA", "MrBayes", "PAML_Baseml", "PAML_codeml", "RAxML", "FASTA", 
                            "HYPHY", "HYPHY Ancestral", "IQ-Tree", "jplace",
                            "jtree", "Newick", "NEXUS", "NHX", "phyloXML", "r8s"),
             selected = NULL
             ),
          br(), br(),
          actionButton(inputId = "parse", label = "Parse Data")
          )
       ),  
        
    tabItem(tabName = "visualization",
        
    fluidRow(
        column(width = 1),
        column(width = 10,
               br(),
               addSpinner(plotOutput("tree"), spin = "dots", color = "#ffffff"), ##### Phylo Plot
        ),
        column(width = 1)
    ),
    
    br(), hr(), ##### Control Panels
        
    fluidRow(
        column(width = 2,
               h3(p("Layout"), style = "color:white"),
               br(),
               fluidRow(
                 column(width = 12,
                        checkboxInput(inputId = "show_layout",
                                      label = "Show layout options",
                                      value = FALSE)
                 )
               ),
               br(),
               conditionalPanel("input.show_layout==true",
               radioButtons("tree_type", 
                            label = h5("Tree Type", style = "color:white"),
                            choices = list("Phylogram", "Chronogram", "Cladogram"), 
                            selected = "Phylogram"),
               br(),
               fluidRow(
               column(width = 10,
               conditionalPanel("input.tree_type=='Phylogram'",
               selectInput("layout",
                           h5("Select Theme", style = "color:white"),
                           choices = list(linear = list("Rectangular" = "rectangular",
                                                        "Roundrect"= "roundrect",
                                                        "Slanted" = "slanted",
                                                        "Ellipse" = "ellipse"),
                                          circular = list("Circular" = "circular",
                                                          "Fan" = "fan"),
                                          unrooted = list("Daylight" = "daylight",
                                                          "Equal Angle" = "equal_angle")),
                           selected = "roundrect",
                           width = "200px")
               ),
               conditionalPanel("input.tree_type=='Chronogram'",
                                selectInput("layout",
                                            h5("Select Theme", style = "color:white"),
                                            choices = list(linear = list("Rectangular" = "rectangular",
                                                                         "Roundrect"= "roundrect",
                                                                         "Ellipse" = "ellipse")),
                                            selected = "roundrect",
                                            width = "200px")
               ),
               conditionalPanel("input.tree_type=='Cladogram'",
                                selectInput("layout",
                                            h5("Select Theme", style = "color:white"),
                                            choices = list(linear = list("Rectangular" = "rectangular",
                                                                         "Roundrect"= "roundrect",
                                                                         "Slanted" = "slanted",
                                                                         "Ellipse" = "ellipse"),
                                                           circular = list("Circular" = "circular",
                                                                           "Fan" = "fan"),
                                                           unrooted = list("Daylight" = "daylight",
                                                                           "Equal Angle" = "equal_angle")),
                                            selected = "roundrect",
                                            width = "200px")
               ),
               ),
               ),
               br(),
               fluidRow(
               column(width = 6,
               colorPickr(inputId = "background_color",
                          label = h5("Background", style = "color:white"),
                          selected = "#282f38",
                          opacity = TRUE,
                          update = "changestop",
                          interaction = list(clear = FALSE, save = FALSE),
                          position = "right-start",
                          swatches = scales::viridis_pal()(10),
                          theme = "nano",
                          useAsButton = TRUE,
                          width = "100%")
               ),
               column(width = 6,
               colorPickr(inputId = "branch_color",
                          label = h5("Branches", style = "color:white"),
                          selected = "#ffffff",
                          opacity = TRUE,
                          update = "changestop",
                          interaction = list(clear = FALSE, save = FALSE),
                          position = "right-start",
                          swatches = scales::viridis_pal()(10),
                          theme = "nano",
                          useAsButton = TRUE,
                          width = "100%")
               )
               )
               )
        ),
        column(width = 2,
               h3(p("Tip Labels"), style = "color:white"),
               br(),
               fluidRow(
                 column(width = 12,
                        checkboxInput(inputId = "label",
                                      label = "Show Tip Labels",
                                      value = FALSE)
                        )
               ),
               br(),
               conditionalPanel("input.label==true",
               fluidRow(
                 column(width = 12,
                        checkboxInput(inputId = "label_angle",
                                      label = "Correct Label Angle",
                                      value = FALSE),
                        numericInput(inputId = "label_size",
                                     label = h5("Size", style = "color:white"),
                                     value = 4,
                                     min = 1,
                                     max = 10,
                                     step = 1,
                                     width = "60px"),
                        colorPickr(inputId = "label_color",
                                   label = h5("Color", style = "color:white"),
                                   selected = "#22e6e6",
                                   opacity = TRUE,
                                   update = "changestop",
                                   interaction = list(clear = FALSE, save = FALSE),
                                   position = "right-start",
                                   swatches = scales::viridis_pal()(10),
                                   theme = "nano",
                                   useAsButton = TRUE,
                                   width = "30%"))
               )
               )
        ),
        column(width = 2,
               h3(p("Scale"), style = "color:white"),
               br(),
               fluidRow(
                 column(width = 12,
                        checkboxInput(inputId = "show_scale",
                                      label = "Show scale",
                                      value = FALSE)
                 )
               ),
               br(),
               conditionalPanel("input.show_scale==true",
               fluidRow(
               column(width = 7,
                      radioButtons("scale", 
                                   label = h5("Type", style = "color:white"),
                                   choices = list("Branch Scale" = 1, "X Scale" = 2), 
                                   selected = 1)),
               column(width = 5,
                      h5(p("Color"), style = "color:white"),
                      colorPickr(inputId = "scale_color",
                                 label = NULL,
                                 selected = "#ffffff",
                                 opacity = TRUE,
                                 update = "changestop",
                                 interaction = list(clear = FALSE, save = FALSE),
                                 position = "right-start",
                                 swatches = scales::viridis_pal()(10),
                                 theme = "nano",
                                 useAsButton = TRUE,
                                 width = "30%"))
               ),
               br(),
               fluidRow(
                  column(width = 5,
                         numericInput(inputId = "scale_x",
                                      label = h5("X", style = "color:white"),
                                      value = 4,
                                      min = 0,
                                      max = 5,
                                      step = 0.5,
                                      width = "70px"),
                         numericInput(inputId = "scale_line",
                                      label = h5("Line size", style = "color:white"),
                                      value = 0.5,
                                      step = 0.2,
                                      width = "70px"),
                         numericInput(inputId = "scale_text",
                                      label = h5("Font size", style = "color:white"),
                                      value = 6.5,
                                      step = 0.5,
                                      max = 12,
                                      min = 4,
                                      width = "70px")
                  ),
                  column(width = 5,
                         numericInput(inputId = "scale_y",
                                      label = h5("Y", style = "color:white"),
                                      value = 0,
                                      step = 1,
                                      min = 0,
                                      max = 30,
                                      width = "70px"),
                         numericInput(inputId = "scale_width",
                                      label = h5("Width", style = "color:white"),
                                      value = 0.3,
                                      step = 0.1,
                                      width = "70px")
                         
                  ),
               )
               ) 
               ),
        column(width = 2,
               h3(p("Nodes"), style = "color:white"),
               br(),
               column(width = 12,
                   fluidRow(
                   checkboxInput(inputId = "node_highlight",
                                 label = "Highlight nodes",
                                 value = FALSE)
                   )
               ),
               br(),
               conditionalPanel("input.node_highlight==true",
               fluidRow(
                 column(width = 10,
                        selectInput(inputId = "node_shape",
                                    label = h5("Shape", style = "color:white"),
                                    choices = c("Square" = 0, "Circle" = 1, "Triangle Point Up" = 2, 
                                                "Plus" = 3, "Cross" = 4, "Diamond" = 5,
                                                "Triangle Point Down" = 6, "Square Cross" = 7, "Star" = 8,
                                                "Diamond Plus" = 9, "Circle Plus" = 10, "Triangles Up Down" = 11,
                                                "Square Plus" = 12, "Circle Cross" = 13, "Square Triangle Down" = 14,
                                                "Filled Square" = 15, "Filled Circle" = 16, "Filled Triangle Up" = 17,
                                                "Filled Diamond" = 18, "Solid Circle" = 19, "Bullet" = 20),
                                    selected = 16)
                        
                 ),
               ),
               fluidRow(
                 column(width = 7,
                        numericInput(inputId = "node_size",
                                     label = h5("Size", style = "color:white"),
                                     value = 3,
                                     min = 1,
                                     max = 10,
                                     step = 1,
                                     width = "70px"),
                        numericInput(inputId = "node_alpha",
                                     label = h5("Opacity", style = "color:white"),
                                     value = 1,
                                     min = 0,
                                     max = 1,
                                     step = 0.1,
                                     width = "70px")
                   
                 ),
                 column(width = 2,
                        colorPickr(inputId = "node_color",
                                   label = h5("Color", style = "color:white"),
                                   selected = "#16eee0",
                                   opacity = TRUE,
                                   update = "changestop",
                                   interaction = list(clear = FALSE, save = FALSE),
                                   position = "right-start",
                                   swatches = scales::viridis_pal()(10),
                                   theme = "nano",
                                   useAsButton = TRUE,
                                   width = "30%")
                 )      
               )
               )
        ),
        column(width = 2,
               h3(p("Tips"), style = "color:white"),
               br(),
               column(width = 12,
                      fluidRow(
                        checkboxInput(inputId = "tip_highlight",
                                      label = "Highlight tips",
                                      value = FALSE)
                      )
               ),
               br(),
               conditionalPanel("input.tip_highlight==true",
               fluidRow(
                 column(width = 10,
                        selectInput(inputId = "tip_shape",
                                    label = h5("Shape", style = "color:white"),
                                    choices = c("Square" = 0, "Circle" = 1, "Triangle Point Up" = 2, 
                                                "Plus" = 3, "Cross" = 4, "Diamond" = 5,
                                                "Triangle Point Down" = 6, "Square Cross" = 7, "Star" = 8,
                                                "Diamond Plus" = 9, "Circle Plus" = 10, "Triangles Up Down" = 11,
                                                "Square Plus" = 12, "Circle Cross" = 13, "Square Triangle Down" = 14,
                                                "Filled Square" = 15, "Filled Circle" = 16, "Filled Triangle Up" = 17,
                                                "Filled Diamond" = 18, "Solid Circle" = 19, "Bullet" = 20),
                                    selected = 4)
                        
                 ),
               ),
               fluidRow(
                 column(width = 7,
                        numericInput(inputId = "tip_size",
                                     label = h5("Size", style = "color:white"),
                                     value = 4,
                                     min = 0,
                                     max = 10,
                                     step = 1, width = "70px"),
                        numericInput(inputId = "tip_alpha",
                                     label = h5("Opacity", style = "color:white"),
                                     value = 1,
                                     min = 0,
                                     max = 1,
                                     step = 0.1,
                                     width = "70px")
                 ),
                 column(width = 2,
                        colorPickr(inputId = "tip_color",
                                   label = h5("Color", style = "color:white"),
                                   selected = "#16eee0",
                                   opacity = TRUE,
                                   update = "changestop",
                                   interaction = list(clear = FALSE, save = FALSE),
                                   position = "right-start",
                                   swatches = scales::viridis_pal()(10),
                                   theme = "nano",
                                   useAsButton = TRUE,
                                   width = "30%")
                 )
               )
               )
        ),
        column(width = 2,
               h3(p("Orientation"), style = "color:white"),
               br(),
               column(width = 6,
                      checkboxInput(inputId = "rev_x_axis", 
                                    label = "Reverse x-Axis", 
                                    value = FALSE),
                      checkboxInput(inputId = "rev_y_axis",
                                    label = "Reverse y-Axis",
                                    value = FALSE)),
               column(width = 6,
                      numericInput("rotate",
                                   label = h5("Angle", style = "color:white"), 
                                   value = 0,
                                   min = -180,
                                   max = 180,
                                   step = 1,
                                   width = "75px"))
        ),
    
    ),
    hr(), br(), br(), br(), br(), br(), br(), 
    fluidRow(
      br(), br(), br(), br(), br(),
          column(width = 4,
                 tags$a(href="https://github.com/infinity-a11y/phylo_tree", "Github Repository (Instructions, Source Code, etc.)")
          ),
          column(width = 4,
          h5(p("Hochschule Furtwangen University"), style = "color:white")
          ),
          column(width = 4,
                 h5(p("Marian Freisleben, Jonathan Simantzik, Prof. Dr. Matthias Kohl "), style = "color:white")
                 )
    )
    ), # End tabItem Visualization
    
    tabItem(
      tabName = "report",
      column(
         br(), br(), br(), br(), br(), br(), br(), br(), br(), br(), br(), br(), br(), br(), br(), br(), br(), br(), br(), br(),
         width = 12,
         align = "center",
         downloadButton("download_report", "Download")
         )
      
      )
    
    ) # End tabItems
    
    ) # End dashboardPage

) # end UI



################### Server ###################

server <- function(input, output) {
    
  
    # parse file depending on select input
    observeEvent(input$parse, {
        
        if (input$select == "BEAST") {
          
          parsed_file <<- read.beast(input$file$datapath)
          phylo <<- as.phylo(parsed_file)
          plot <- ggtree(phylo)
          
            if (class(parsed_file) == "treedata" & class(phylo) == "phylo") {
              
              show_toast(title = "Parsing successful",
                         type = "success",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
              
            } else {
              
               show_toast(title = "Error",
                          type = "error",
                          position = "bottom",
                          width = "400px",
                          timer = 4000)
              
            }
          
        } else if (input$select == "MEGA") {
          
          parsed_file <<- read.mega(input$file$datapath)
          phylo <<- as.phylo(parsed_file)
          plot <- ggtree(phylo)
          
            if (class(parsed_file) == "treedata" & class(phylo) == "phylo") {
              
              show_toast(title = "Success",
                         type = "success",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
             
            } else {
              
               show_toast(title = "Error",
                          type = "error",
                          position = "bottom",
                          width = "400px",
                          timer = 4000)
              
            }
          
        } else if (input$select == "MrBayes") {
          
          parsed_file <<- read.mrbayes(input$file$datapath)
          phylo <<- as.phylo(parsed_file)
          plot <- ggtree(phylo)
          
          if (class(parsed_file) == "treedata" & class(phylo) == "phylo") {
            show_toast(title = "Success",
                       type = "success",
                       position = "bottom",
                       width = "400px",
                       timer = 4000)
            
          } else {
            
             show_toast(title = "Error",
                        type = "error",
                        position = "bottom",
                        width = "400px",
                        timer = 4000)
            
          }
        } else if (input$select == "FASTA") {
           
           parsed_file <<- read.fasta(input$file$datapath)
           phylo <<- as.phylo(parsed_file)
           plot <- ggtree(phylo)
           
           if (class(parsed_file) == "treedata" & class(phylo) == "phylo") {
              show_toast(title = "Success",
                         type = "success",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
              
           } else {
              
              show_toast(title = "Error",
                         type = "error",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
              
           }
        } else if (input$select == "HYPHY") {
           
           parsed_file <<- read.hyphy(input$file$datapath)
           phylo <<- as.phylo(parsed_file)
           plot <- ggtree(phylo)
           
           if (class(parsed_file) == "treedata" & class(phylo) == "phylo") {
              show_toast(title = "Success",
                         type = "success",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
              
           } else {
              
              show_toast(title = "Error",
                         type = "error",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
              
           }
        } else if (input$select == "HYPHY Ancestral") {
           
           parsed_file <<- read.hyphy.seq(input$file$datapath)
           phylo <<- as.phylo(parsed_file)
           plot <- ggtree(phylo)
           
           if (class(parsed_file) == "treedata" & class(phylo) == "phylo") {
              show_toast(title = "Success",
                         type = "success",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
              
           } else {
              
              show_toast(title = "Error",
                         type = "error",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
              
           }
        } else if (input$select == "IQ-Tree") {
           
           parsed_file <<- read.iqtree(input$file$datapath)
           phylo <<- as.phylo(parsed_file)
           plot <- ggtree(phylo)
           
           if (class(parsed_file) == "treedata" & class(phylo) == "phylo") {
              show_toast(title = "Success",
                         type = "success",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
              
           } else {
              
              show_toast(title = "Error",
                         type = "error",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
              
           }
        } else if (input$select == "jplace") {
           
           parsed_file <<- read.jplace(input$file$datapath)
           phylo <<- as.phylo(parsed_file)
           plot <- ggtree(phylo)
           
           if (class(parsed_file) == "treedata" & class(phylo) == "phylo") {
              show_toast(title = "Success",
                         type = "success",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
              
           } else {
              
              show_toast(title = "Error",
                         type = "error",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
              
           }
        } else if (input$select == "jtree") {
           
           parsed_file <<- read.jtree(input$file$datapath)
           phylo <<- as.phylo(parsed_file)
           plot <- ggtree(phylo)
           
           if (class(parsed_file) == "treedata" & class(phylo) == "phylo") {
              show_toast(title = "Success",
                         type = "success",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
              
           } else {
              
              show_toast(title = "Error",
                         type = "error",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
              
           }
        } else if (input$select == "Newick") {
           
           parsed_file <<- read.newick(input$file$datapath)
           phylo <<- as.phylo(parsed_file)
           plot <- ggtree(phylo)
           
           if (class(parsed_file) == "treedata" & class(phylo) == "phylo") {
              show_toast(title = "Success",
                         type = "success",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
              
           } else {
              
              show_toast(title = "Error",
                         type = "error",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
              
           }
        } else if (input$select == "NEXUS") {
           
           parsed_file <<- read.nexus(input$file$datapath)
           phylo <<- as.phylo(parsed_file)
           plot <- ggtree(phylo)
           
           if (class(parsed_file) == "treedata" & class(phylo) == "phylo") {
              show_toast(title = "Success",
                         type = "success",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
              
           } else {
              
              show_toast(title = "Error",
                         type = "error",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
              
           }
        } else if (input$select == "NHX") {
           
           parsed_file <<- read.nhx(input$file$datapath)
           phylo <<- as.phylo(parsed_file)
           plot <- ggtree(phylo)
           
           if (class(parsed_file) == "treedata" & class(phylo) == "phylo") {
              show_toast(title = "Success",
                         type = "success",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
              
           } else {
              
              show_toast(title = "Error",
                         type = "error",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
              
           }
        } else if (input$select == "RAxML") {
           
           parsed_file <<- read.raxml(input$file$datapath)
           phylo <<- as.phylo(parsed_file)
           plot <- ggtree(phylo)
           
           if (class(parsed_file) == "treedata" & class(phylo) == "phylo") {
              show_toast(title = "Success",
                         type = "success",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
              
           } else {
              
              show_toast(title = "Error",
                         type = "error",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
              
           }
        } else if (input$select == "r8s") {
           
           parsed_file <<- read.r8s(input$file$datapath)
           phylo <<- as.phylo(parsed_file)
           plot <- ggtree(phylo)
           
           if (class(parsed_file) == "treedata" & class(phylo) == "phylo") {
              show_toast(title = "Success",
                         type = "success",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
              
           } else {
              
              show_toast(title = "Error",
                         type = "error",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
              
           }
        } else if (input$select == "phyloXML") {
           
           parsed_file <<- read.phyloxml(input$file$datapath)
           phylo <<- as.phylo(parsed_file)
           plot <- ggtree(phylo)
           
           if (class(parsed_file) == "treedata" & class(phylo) == "phylo") {
              show_toast(title = "Success",
                         type = "success",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
              
           } else {
              
              show_toast(title = "Error",
                         type = "error",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
              
           }
        } else if (input$select == "PAML_Baseml") {
           
           parsed_file <<- read.paml_rst(input$file$datapath)
           phylo <<- as.phylo(parsed_file)
           plot <- ggtree(phylo)
           
           if (class(parsed_file) == "treedata" & class(phylo) == "phylo") {
              show_toast(title = "Success",
                         type = "success",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
              
           } else {
              
              show_toast(title = "Error",
                         type = "error",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
              
           }
        } else if (input$select == "PAML_codeml") {
           
           parsed_file <<- read.paml_rst(input$file$datapath)
           phylo <<- as.phylo(parsed_file)
           plot <- ggtree(phylo)
           
           if (class(parsed_file) == "treedata" & class(phylo) == "phylo") {
              show_toast(title = "Success",
                         type = "success",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
              
           } else {
              
              show_toast(title = "Error",
                         type = "error",
                         position = "bottom",
                         width = "400px",
                         timer = 4000)
              
           }
        } 
        
        
      
    })
    
    
    # Define Tree Characteristics
    # Reverse X Scale
    revx <- reactive({
      if(input$rev_x_axis == FALSE) {
        NULL
      } else if (input$rev_x_axis == TRUE) {
        scale_x_reverse()
      }
    })
    
    # Reverse Y Scale
    revy <- reactive({
      if(input$rev_y_axis == FALSE) {
        NULL
      } else if (input$rev_y_axis == TRUE) {
        scale_y_reverse()
      }
    })
    
    # Treescale
    # Add treescale
    treescale_x <- reactive({
      if(input$scale == 1 & input$show_scale == TRUE) {
        
        geom_treescale(color = color_scale(),
                       y = y_scale(),
                       x = x_scale(),
                       linesize = line_scale(),
                       fontsize = text_scale(),
                       width = width_scale())
        
      } else if (input$scale == 2 & input$show_scale == TRUE) {
        
        theme_tree2()
        
      } else if (input$show_scale == FALSE) {
        
        NULL
        
      }
    })
    
    # Scale Color
    color_scale <- reactive({input$scale_color})
    
    # Scale Y Pos
    y_scale <- reactive({input$scale_y})
    
    # Scale x Pos
    x_scale <- reactive({input$scale_x})
    
    # Scale Line Size
    line_scale <- reactive({input$scale_line})
    
    # Scale Y Pos
    text_scale <- reactive({input$scale_text})
    
    #SCale Width
    width_scale <- reactive({input$scale_width})
    
    # Highlight tips 
    tip <- reactive({
      
      if(input$tip_highlight == FALSE) {
        
        NULL
        
      } else if (input$tip_highlight == TRUE) {
        
        geom_tippoint(shape = as.numeric(input$tip_shape),
                       color = input$tip_color,
                       size = input$tip_size,
                       alpha = input$tip_alpha)
        
      }
      
    })
    
    #highlight nodes
    node <- reactive({
      
      if(input$node_highlight == FALSE) {
        
        NULL
        
      } else if (input$node_highlight == TRUE) {
        
        geom_nodepoint(shape = as.numeric(input$node_shape),
                      color = input$node_color,
                      size = input$node_size,
                      alpha = input$node_alpha)
        
      }
      
    })
    
    # Tip Labels
    
    label <- reactive ({
      
      if(input$label == FALSE) {
        
        NULL
        
      } else if (input$label) {
        
        geom_tiplab(size = input$label_size, 
                    color = input$label_color,
                    mapping = aes(angle = angle()))
        
      }
      
    })
    
    # Label Angle
    angle <- reactive({
      
      if(input$label_angle == FALSE) {
        
        NULL
        
      } else {
        
        angle
        
      }
      
    })
    
    # Branch Color
    color <- reactive({input$branch_color})
    
    # Background Color
    b_color <- reactive({input$background_color})
    
    # Generate Random Plot
    randomtree <- reactive({
      
      rtree <- rtree(input$ntree)
      
    })
    
    observeEvent(input$random_tree, 
                 {output$tree <- renderPlot({
                   
                   tree_plot <<- as.ggplot(ggtree(tr = randomtree(),
                                            aes(color = I(color())),
                                            layout = input$layout) +
                                                revx() +
                                                revy() +
                                                treescale_x() +
                                                tip() +
                                                label() +
                                                node() +
                                                theme(plot.background = element_rect(fill = b_color(),
                                                                                           color = b_color()),
                                                      panel.background = element_rect(fill = b_color(),
                                                                                      color = b_color())), 
                                      angle = input$rotate)
                   tree_plot
                   
                   })
                 })
    
    # Make Phylogram Plot
    observeEvent(input$make_tree, 
                 {output$tree <- renderPlot({
                   
                    tree_plot <- as.ggplot(ggtree(tr = phylo,
                                     aes(color = I(color())),
                                     layout = input$layout) +
                                revx() +
                                revy() +
                                treescale_x() +
                                tip() +
                                label() +
                                node() +
                                theme(plot.background = element_rect(fill = b_color(),
                                                                     color = b_color()),
                                      panel.background = element_rect(fill = b_color(),
                                                                      color = b_color())), 
                              angle = input$rotate)
                   tree_plot
                    
                   })
                 }
    
    )
    
    # download report
    output$download_report <- downloadHandler(
       filename = function() {
          paste(Sys.Date(), "_tree_plot.png", sep="")
       },
       content = function(file) {
          ggsave(
             file,
             plot = tree_plot,
             device = NULL,
             path = NULL,
             scale = 1,
             width = NA,
             height = NA,
             units = c("in", "cm", "mm", "px"),
             dpi = 300,
             limitsize = TRUE,
             bg = NULL,
             ...
          )
       }
    )
    
}


################## Shiny #####################

shinyApp(ui = ui, server = server)
